#pragma once

//QT includes
#include <QtWebEngineQuick/QtWebEngineQuick>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QTranslator>
