#pragma once

//C++20 includes
#include <string>
#include <memory>

//QT includes
#include <QtWebEngineQuick/QtWebEngineQuick>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QTranslator>
#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QString>
#include <QJsonDocument>
#include <QUrl>
#include <QQmlContext>
