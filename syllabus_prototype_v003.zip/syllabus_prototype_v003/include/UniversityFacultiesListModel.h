#pragma once
#include <QAbstractListModel>
#include <QVector>
#include <QByteArray>
#include <QStringListModel>
#include "Requests.h"


class UniversityFacultiesListModel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(short currentIndex READ currentIndex WRITE setCurrentIndex NOTIFY currentIndexChanged);
    Q_PROPERTY(QObject* faculties READ faculties WRITE setFaculties NOTIFY facultiesChanged);
public:
    explicit UniversityFacultiesListModel(QObject *parent = nullptr);

    enum{
        DoneRole = Qt::UserRole, DescriptionRole
    };

    //Header:
    QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const override;

    // Basic functionality:
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;

    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;

    Q_INVOKABLE void setModelData(Requests::universityFacultiesListModel data);

    Q_INVOKABLE QStringList getFaculties(int index) const;

    short currentIndex();

    virtual QHash<int,QByteArray> roleNames() const override;

    QObject* faculties();
signals:
    void currentIndexChanged();
    void facultiesChanged();
public slots:
    void setCurrentIndex(short currentIndex);
    void setFaculties(QObject * object);
    void allFaculties();
private:
    class FacultiesListModel : public QAbstractListModel{
    public:
        // Basic functionality:
        int rowCount(const QModelIndex &parent = QModelIndex()) const override;

        QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;

        virtual QHash<int,QByteArray> roleNames() const override;

        void setModelData(QStringList faculties);
    private:
        QStringList faculties;
    };

private:
    Requests::universityFacultiesListModel m_data;
    short m_currentIndex = 0;
    std::shared_ptr<FacultiesListModel> faultiesListModel = std::make_shared<FacultiesListModel>();
};

