#pragma once
#include <QObject>
#include <QGuiApplication>
#include <QCoreApplication>
#include <QQmlApplicationEngine>
//#include "User.h"


constexpr const char* singleton = "qrc:/qml/Constants.qml";
constexpr const char* qmlMainFile = "qrc:/qml/main.qml";


class AppInit
{
public:
    AppInit(int& argc,char* argv[]);
    int execute();
private:
    void init();
    void initQmlEngine();
    void registerQmlType();
    void registerContextProperties();
private:
    QQmlApplicationEngine engine;
    QGuiApplication app;
    //User user;
};




