#pragma once

#include <memory>
#include <tuple>
#include <QObject>
#include <QJsonDocument>
#include <QJsonObject>
#include <QVariantMap>
#include <QByteArray>
#include "DatabaseHandler.h"

class Requests : public QObject{
    Q_OBJECT
public:
    using SignUpTuple = std::tuple<QString,QString,bool>;
    using SignInTuple = SignUpTuple;
    explicit Requests(QObject * parent = nullptr);
    ~Requests();
    void makeSignUpWithEmailAndPasswordRequest(const QString& username,const QString& password);
    void makeSignInWithEmailAndPasswordRequest(const QString& username,const QString& password);
    void makeGetUserDataRequest(const QString& idToken);
signals:
    void accessGranted(QString idToken);
    void registered(QString idToken);
    void accessDenied();
    void signUpFailed();
public slots:
    void readSignUpResponse();
    void readSignInResponse();
private:
    QString signUpWithEmailAndPasswordEndPoint();
    QString signInWithEmailAndPasswordEndPoint();
    QString getUserDataEndPoint();
    void readSignUpResponseContent(const QJsonObject& jsonObject);
    void readSignInResponseContent(const QJsonObject& jsonObject);
private:
    template<class T>
    struct PayLoad{
        PayLoad(T data);
        enum SignInSignUp{
            Username,Password,ReturnSecureToken
        };
        const QVariantMap getSignInWithEmailPasswordPayLoad() const;
        const QVariantMap getSignUpWithEmailPasswordPayLoad() const;
        const QJsonDocument getDocumentBody(const QVariantMap& payLoad) const;
    private:
        T data;
    };
private:
    std::shared_ptr<DatabaseHandler> database = nullptr;
    DatabaseHandler::Reply* reply = nullptr;
};
