#pragma once
//QT includes
#include <memory>
#include <QVariantMap>
#include <string>

#include "Requests.h"

class User : public QObject
{
    Q_OBJECT
public:
    explicit User(QObject *parent = nullptr);
    const Requests* getRequests() const;
signals:
    void userSignedIn();
public slots:
    void grantAccess(const QString& username,const QString& password);
    void signUpUser(const QVariantMap& registerForm);
    void accessGranted(QString idToken);
    void accessDenied();
    void registered(QString idToken);
private:
    struct UserProfile{
        UserProfile(const QString& idToken);
        void setIdToken(const QString& idToken);
        const std::string getIdToken() const;
    private:
        std::string idToken;
    };
private:
    std::shared_ptr<Requests> requests = nullptr;
    std::unique_ptr<UserProfile> userProfile = nullptr;
};

