#pragma once

#include <memory>

#include <QObject>
#include <QString>
#include <QNetworkAccessManager>
#include <QJsonDocument>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QByteArray>
#include <QStringView>
#include <functional>


class DatabaseHandler : public QObject{
    Q_OBJECT
public:
    using Manager = std::shared_ptr<QNetworkAccessManager>;
    using Reply = QNetworkReply;
    using Request = QNetworkRequest;
public:
    explicit DatabaseHandler(QObject * parent = nullptr,const QString apiKey = "AIzaSyA-qupn4cWUvOb9S2qs1SikLZPiS_cbT5g");
    Reply* GET(const QString& url);
    Reply* POST(const QString& url,const QJsonDocument& document,const char* contentTypeHeader);
    void setApiKey(const QString& apiKey);
    QString getApiKey();
    ~DatabaseHandler();
private:
    Manager manager;
    Reply* reply;
    QString apiKey;
};

