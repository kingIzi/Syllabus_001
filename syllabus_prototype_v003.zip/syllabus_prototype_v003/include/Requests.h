#pragma once

#include "DatabaseHandler.h"
#include <QObject>
#include <QList>

class Requests : public QObject{
    Q_OBJECT
public:
    Requests(QObject * parent = nullptr);
    ~Requests();
public:
    using SignInTuple = std::tuple<QString,QString,bool>; //email,password,returnSecureToken
    using SignUpTuple = SignInTuple;
    using universityFacultiesListModel = QList<QPair<QString,QStringList>>;
signals:
    //authentication
    void accessDenied();
    void accessGranted(QString);
    void signUpSuccessful(QString);
    void signUpFailed(QString);

    //register user
    void allUniversities(universityFacultiesListModel);
    void universitiesFacultiesModelData(QStringList,QStringList);
public slots:
    void grantAccess(const QString& email,const QString& password);
    void userSignUp(const QString& email,const QString& password, const QString& telephone);
    void universityData();
private:
    void login();
    void signUp(const QString& telephone);
    void makeUniversitiesRequest();
private:
    template<class T>
    class RequestBody{
    public:
        enum SignInSignUp{
            Email,Password,ReturnSecureToken
        };
        RequestBody(T requiredData);
        RequestBody();
        //sign in user with email and password
        const QJsonDocument getGrantAccessRequestBody() const;
        const QString getSignInUsernamePasswordEndPoint() const;
        const QString getSignUpUsernamePasswordEndPoint() const;
        const QJsonDocument getSignUpRequestBody() const;

        const QString getUniversitiesEndPoint() const;
    private:
        const QVariantMap getGrantAccessVariant() const;
        const QVariantMap getSignUpVariant() const;
        const QString databaseUrl() const;
    private:
        const T requiredData;
    };

private:
    std::shared_ptr<DatabaseHandler> database = nullptr;
};
