#pragma once

#include "DatabaseHandler.h"
#include <QObject>

class Requests : public QObject{
    Q_OBJECT
public:
    Requests(QObject * parent = nullptr);
    ~Requests();
public:
    using SignInTuple = std::tuple<QString,QString,bool>; //email,password,returnSecureToken
    using SignUpTuple = SignInTuple;
signals:
    void accessDenied();
    void accessGranted(QString);
    void signUpSuccessful(QString);
    void signUpFailed(QString);
public slots:
    void grantAccess(const QString& email,const QString& password);
    void userSignUp(const QString& email,const QString& password, const QString& telephone);
private:
    void login();
    void signUp(const QString& telephone);
private:
    template<class T>
    class RequestBody{
    public:
        enum SignInSignUp{
            Email,Password,ReturnSecureToken
        };
        RequestBody(T requiredData);
        //sign in user with email and password
        const QJsonDocument getGrantAccessRequestBody() const;
        const QString getSignInUsernamePasswordEndPoint() const;
        const QString getSignUpUsernamePasswordEndPoint() const;
        const QJsonDocument getSignUpRequestBody() const;
    private:
        const QVariantMap getGrantAccessVariant() const;
        const QVariantMap getSignUpVariant() const;
    private:
        const T requiredData;
    };
private:
    std::shared_ptr<DatabaseHandler> database = nullptr;
};
