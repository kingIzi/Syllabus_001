#pragma once

#include <QObject>
#include <QVariantList>
#include <QList>
#include <QPair>
#include <QStringList>
#include <QJsonDocument>

class Response : public QObject{
public:
    Response(const QJsonDocument& document);
    ~Response();
    const QList<QPair<QString,QStringList>> getAllUniversities() const;
    const QStringList getAllFaculties(const QVariantList& faculties) const;
private:
    const QJsonDocument document;

};
