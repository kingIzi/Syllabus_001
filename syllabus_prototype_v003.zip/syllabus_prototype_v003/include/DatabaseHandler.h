#pragma once

#include <memory>
#include <string>
#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QString>
#include <QJsonDocument>

//constexpr const char* APIKEY = "AIzaSyA-qupn4cWUvOb9S2qs1SikLZPiS_cbT5g";



class DatabaseHandler : public QObject{
    Q_OBJECT
public:
    using Manager = QNetworkAccessManager;
    using Request = QNetworkRequest;
    using Reply = QNetworkReply;
public:
    explicit DatabaseHandler(QObject * parent = nullptr);
    ~DatabaseHandler();
    Reply* GET(const QString& url);
    Reply* POST(const QString& url,const QJsonDocument& document,const char* contentHeader);
    static const QString getApiKey();
    void setApiKey(const QString apiKey);
    Reply* getReplyHandler() const;
    void makeSharedReplyHandler(Reply* reply);
public:
private:
    std::unique_ptr<Manager> manager = nullptr;
    std::shared_ptr<Reply*> replyHandler = nullptr;
    static std::string APIKEY;
};
