#pragma once

#include <QObject>
#include "Requests.h"

class User : public QObject{
    Q_OBJECT
public:
    explicit User(QObject * parent = nullptr);
    ~User();
    void setIdToken(const QString& idToken);
    const QString getIdToken() const;
    Q_INVOKABLE Requests* getRequests();
signals:
    void signIn(QString,QString);
    void signUp(QString,QString,QString);
    void userSignedUp();
public slots:
    void signInFailed();
    void signInSuccessful(QString);
    void signUpSuccessful(QString);
private:
    void authSignalsAndSlots();
private:
    std::shared_ptr<Requests> requests = nullptr;
    std::string idToken;
};
