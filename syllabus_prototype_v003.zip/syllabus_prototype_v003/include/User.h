#pragma once
#include <QObject>

class User : public QObject
{
    Q_OBJECT
public:
    User(QObject * parent = nullptr);
    virtual ~User();
};
