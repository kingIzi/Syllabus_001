//#include "UniversityFacultiesModel.h"

//UniversityFacultiesModel::UniversityFacultiesModel(QObject *parent)
//    : QAbstractListModel(parent)
//{
//}

//Requests::universityFacultiesListModel UniversityFacultiesModel::getData() const
//{
//    return this->m_data;
//}

//void UniversityFacultiesModel::setModelData(Requests::universityFacultiesListModel data)
//{
//    this->m_data = data;
//}

//QVariant UniversityFacultiesModel::headerData(int section, Qt::Orientation orientation, int role) const
//{
//    // FIXME: Implement me!
//    return QVariant();
//}

//int UniversityFacultiesModel::rowCount(const QModelIndex &parent) const
//{
//    // For list models only the root node (an invalid parent) should return the list's size. For all
//    // other (valid) parents, rowCount() should return 0 so that it does not become a tree model.
//    if (parent.isValid())
//        return 0;
//    // FIXME: Implement me!
//    return this->m_data.size();
//}

//QVariant UniversityFacultiesModel::data(const QModelIndex &index, int role) const
//{
//    if (!index.isValid())
//        return QVariant();

//    // FIXME: Implement me!
//    return this->m_data.at(index.row()).first;
//    //return QVariant();
//}

//QHash<int, QByteArray> UniversityFacultiesModel::roleNames() const
//{
//    return QHash<int,QByteArray>();
//}

#include "UniversityFacultiesModel.h"

UniversityFacultiesListModel::UniversityFacultiesListModel(QObject *parent) :
    QAbstractListModel(parent)
{

}

UniversityFacultiesListModel::~UniversityFacultiesListModel()
{

}

QVariant UniversityFacultiesListModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    return QVariant();
}

int UniversityFacultiesListModel::rowCount(const QModelIndex &parent) const
{
    return 0;
}

QVariant UniversityFacultiesListModel::data(const QModelIndex &index, int role) const
{
    return QVariant();
}
