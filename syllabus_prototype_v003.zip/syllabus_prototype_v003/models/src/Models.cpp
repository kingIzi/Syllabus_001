#include "Models.h"

Models::Models(QObject *parent) : QObject(parent)
{

}

