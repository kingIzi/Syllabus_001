#pragma once

#include <memory>
#include <QObject>
#include "UniversityFacultiesModel.h"


class Models : public QObject{
    Q_OBJECT
public:
    explicit Models(QObject * parent = nullptr);
    ~Models();

private:
    //std::unique_ptr<UniversityFacultiesModel> universityFacultiesListModel = nullptr;
};
