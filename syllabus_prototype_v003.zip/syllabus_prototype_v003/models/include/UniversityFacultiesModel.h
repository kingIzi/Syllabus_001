#pragma once

#include <QAbstractListModel>
//#include <QList>
//#include <QPair>
//#include <QStringList>
//#include <QString>
//#include <QByteArray>
//#include <QHash>
#include "Requests.h"

class UniversityFacultiesListModel : public QAbstractListModel
{
    Q_OBJECT
public:
    explicit UniversityFacultiesListModel(QObject * parent = nullptr);
    ~UniversityFacultiesListModel();
    QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const override;
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
//public slots:
//    void setModelData(Requests::universityFacultiesListModel data);
//public:
//    explicit UniversityFacultiesModel(QObject *parent = nullptr);
//    Requests::universityFacultiesListModel getData() const;

//    // Header:
//    QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const override;

//    // Basic functionality:
//    int rowCount(const QModelIndex &parent = QModelIndex()) const override;

//    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;

//    virtual QHash<int,QByteArray> roleNames() const override;

//private:
//    Requests::universityFacultiesListModel m_data;
};


