#include <QtWebEngineQuick/QtWebEngineQuick>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QTranslator>
#include <QQmlContext>
#include "User.h"
#include "UniversityFacultiesListModel.h"


int main(int argc,char* argv[]){
    QtWebEngineQuick::initialize();
    QGuiApplication app(argc, argv);
    QTranslator translator;
    const QStringList uiLanguages = QLocale::system().uiLanguages();
    for (const QString &locale : uiLanguages) {
        const QString baseName = "makomi_" + QLocale(locale).name();
        if (translator.load(":/i18n/" + baseName)) {
            app.installTranslator(&translator);
            break;
        }
    }

    QQmlApplicationEngine engine;
    qmlRegisterSingletonType(QUrl("qrc:/qml/Constants.qml"), "SyLib", 1, 0, "Constants");
    qmlRegisterType<UniversityFacultiesListModel>("Sy.Models",1,0,"UniversityFacultiesListModel");
    const QUrl url("qrc:/qml/main.qml");
    User user;
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.rootContext()->setContextProperty("user",&user);
    engine.load(url);

    return app.exec();
}
