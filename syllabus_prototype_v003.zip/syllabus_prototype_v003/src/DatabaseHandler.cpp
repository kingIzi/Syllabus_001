#include <QUrl>
#include "DatabaseHandler.h"

std::string DatabaseHandler::APIKEY = "AIzaSyA-qupn4cWUvOb9S2qs1SikLZPiS_cbT5g";

DatabaseHandler::DatabaseHandler(QObject * parent) :
    QObject(parent)
{
    this->manager = std::make_unique<Manager>(this);
}

DatabaseHandler::~DatabaseHandler()
{

}

DatabaseHandler::Reply* DatabaseHandler::GET(const QString &url)
{
    Request req((QUrl(url)));
    return this->manager.get()->get(req);
}

DatabaseHandler::Reply* DatabaseHandler::POST(const QString &url, const QJsonDocument &document, const char *contentHeader)
{
    Request req((QUrl(url)));
    req.setHeader(Request::ContentTypeHeader,contentHeader);
    return this->manager.get()->post(req,document.toJson());
}

DatabaseHandler::Reply* DatabaseHandler::getReplyHandler() const
{
    return static_cast<Reply*>((*this->replyHandler.get()));
}

void DatabaseHandler::makeSharedReplyHandler(Reply *reply)
{
    this->replyHandler = std::make_shared<Reply*>(reply);
}

void DatabaseHandler::setApiKey(const QString apiKey)
{
    if (apiKey.compare(this->APIKEY.c_str(),Qt::CaseSensitive) != 0){
        this->APIKEY = apiKey.toStdString();
    }
}

const QString DatabaseHandler::getApiKey()
{
    return static_cast<const QString>(DatabaseHandler::APIKEY.c_str());
}
