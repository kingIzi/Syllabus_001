#include "Response.h"

Response::Response(const QJsonDocument& document) :
    document(document)
{

}

Response::~Response()
{

}

const QList<QPair<QString,QStringList>> Response::getAllUniversities() const
{
    const auto responses = this->document.object();
    QVector<QPair<QString,QStringList>> departments;
    departments.reserve(responses.length());
    for (const auto& response : responses){
        const auto hasFaculties = [response]() -> bool { return !response.toObject()["faculties"].toVariant().isNull(); };
        if (hasFaculties()){
            const auto facultiesList = qvariant_cast<QVariantList>(response.toObject()["faculties"].toVariant());
            const auto data = qMakePair(response.toObject()["name"].toString(),this->getAllFaculties(facultiesList));
            departments.push_back(data);
        }
    }
    return departments;
}

const QStringList Response::getAllFaculties(const QVariantList& faculties) const
{
    QStringList allFaculties;
    for (const auto& faculty : faculties){
        allFaculties.append(faculty.toString());
    }
    return allFaculties;
}
