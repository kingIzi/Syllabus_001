#include <QtWebEngineQuick/QtWebEngineQuick>
#include <QLocale>
#include <QTranslator>
#include <QUrl>
#include <QQmlContext>

#include "AppInit.h"


AppInit::AppInit(int &argc, char *argv[]) : app(argc,argv)
{
    this->init();
    this->registerQmlType();
    this->registerContextProperties();
    this->initQmlEngine();
}

int AppInit::execute()
{
    return this->app.exec();
}

void AppInit::init()
{
    QTranslator translator;
    const auto uiLanguages = QLocale::system().uiLanguages();
    for (const auto &locale : uiLanguages) {
        const auto baseName = "syllabus_prototype_v003_" + QLocale(locale).name();
        if (translator.load(":/i18n/" + baseName)) {
            this->app.installTranslator(&translator);
            break;
        }
    }
}

void AppInit::initQmlEngine()
{
    const QUrl url(qmlMainFile);
    QObject::connect(&this->engine, &QQmlApplicationEngine::objectCreated,
                     &this->app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QGuiApplication::exit(-1);
    }, Qt::QueuedConnection);
    this->engine.load(url);
}

void AppInit::registerQmlType()
{
    qmlRegisterSingletonType(QUrl(singleton), "SyLib", 1, 0, "Constants");
}

void AppInit::registerContextProperties()
{
    //this->engine.rootContext()->setContextProperty("user",&this->user);
}

