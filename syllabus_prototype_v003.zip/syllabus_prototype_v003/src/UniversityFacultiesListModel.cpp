#include "UniversityFacultiesListModel.h"

UniversityFacultiesListModel::UniversityFacultiesListModel(QObject *parent)
    : QAbstractListModel(parent)
{
    QObject::connect(this,&UniversityFacultiesListModel::currentIndexChanged,this,&UniversityFacultiesListModel::allFaculties);
}

QVariant UniversityFacultiesListModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    // FIXME: Implement me!
    return QVariant();
}

int UniversityFacultiesListModel::rowCount(const QModelIndex &parent) const
{
    // For list models only the root node (an invalid parent) should return the list's size. For all
    // other (valid) parents, rowCount() should return 0 so that it does not become a tree model.
    if (parent.isValid())
        return 0;
    return this->m_data.size();
    // FIXME: Implement me!
}

QVariant UniversityFacultiesListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
        return QVariant();

    // FIXME: Implement me!
    switch (role){
    case DoneRole:
        return QVariant();
    case DescriptionRole:
        return this->m_data.at(index.row()).first;
    default:
        return QVariant();
    }
    return QVariant();
}

void UniversityFacultiesListModel::setModelData(Requests::universityFacultiesListModel data)
{
    beginResetModel();
    this->m_data = data;
    endResetModel();
    qDebug() << "Model reset";
}

short UniversityFacultiesListModel::currentIndex()
{
    return this->m_currentIndex;
}

void UniversityFacultiesListModel::setCurrentIndex(short currentIndex){
    if (currentIndex != this->m_currentIndex){
        this->m_currentIndex = currentIndex;
        emit UniversityFacultiesListModel::currentIndexChanged();
    }
}

QStringList UniversityFacultiesListModel::getFaculties(int index) const
{
    return this->m_data.at(index).second;
}

QHash<int,QByteArray> UniversityFacultiesListModel::roleNames() const
{
    QHash<int,QByteArray> names;
    names[DoneRole] = "done";
    names[DescriptionRole] = "university";
    return names;
}

void UniversityFacultiesListModel::setFaculties(QObject * object)
{}

void UniversityFacultiesListModel::allFaculties()
{
    const auto data = this->m_data.at(this->currentIndex()).second;
    this->faultiesListModel.get()->setModelData(data);
    emit UniversityFacultiesListModel::facultiesChanged();
}

QObject* UniversityFacultiesListModel::faculties()
{
    return this->faultiesListModel.get();
}

int UniversityFacultiesListModel::FacultiesListModel::rowCount(const QModelIndex &parent) const
{
    if (parent.isValid())
        return 0;
    return this->faculties.size();
}

QVariant UniversityFacultiesListModel::FacultiesListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
        return QVariant();
    return this->faculties.at(index.row());
}

QHash<int,QByteArray> UniversityFacultiesListModel::FacultiesListModel::roleNames() const
{
    QHash<int,QByteArray> names;
    names[DoneRole] = "faculty";
    return names;
}

void UniversityFacultiesListModel::FacultiesListModel::setModelData(QStringList faculties)
{
    this->beginResetModel();
    this->faculties = faculties;
    this->endResetModel();
}



