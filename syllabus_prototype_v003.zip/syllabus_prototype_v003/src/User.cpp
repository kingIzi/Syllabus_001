#include "User.h"

User::User(QObject * parent) :
    QObject(parent)
{

}

User::~User()
{

}
