#include <User.h>

User::User(QObject * parent) :
    QObject(parent)
{
    this->requests = std::make_shared<Requests>();
    this->authSignalsAndSlots();
}

User::~User()
{

}

void User::authSignalsAndSlots()
{
    //sign in
    QObject::connect(this,&User::signIn,this->requests.get(),&Requests::grantAccess);
    QObject::connect(this->requests.get(),&Requests::accessDenied,this,&User::signInFailed);
    QObject::connect(this->requests.get(),&Requests::accessGranted,this,&User::signInSuccessful);
    //sign up
    QObject::connect(this,&User::signUp,this->requests.get(),&Requests::userSignUp);
    QObject::connect(this->requests.get(),&Requests::signUpSuccessful,this,&User::signUpSuccessful);
    QObject::connect(this,&User::userSignedUp,this->requests.get(),&Requests::universityData);
}

void User::setIdToken(const QString& idToken)
{
    if ((idToken.compare(this->idToken.c_str()) != 0)){
        this->idToken = idToken.toStdString();
    }
}

Requests* User::getRequests()
{
    return static_cast<Requests*>(this->requests.get());
}

const QString User::getIdToken() const
{
    return static_cast<const QString>(this->idToken.c_str());
}

void User::signInFailed()
{
    qDebug() << "sign in failed";
}

void User::signInSuccessful(QString idToken)
{
    this->setIdToken(idToken);
}

void User::signUpSuccessful(QString idToken)
{
    this->setIdToken(idToken);
}
