#include <QJsonObject>
#include <QJsonArray>
#include "Requests.h"
#include "Response.h"


Requests::Requests(QObject * parent) :
    QObject(parent)
{
    this->database = std::make_shared<DatabaseHandler>();
}

Requests::~Requests()
{

}

void Requests::grantAccess(const QString& email,const QString& password)
{
    if (email.isEmpty() || password.isEmpty()){
        emit this->accessDenied();
    }
    else{
        const auto data = static_cast<SignInTuple>(std::make_tuple(email,password,true));
        const RequestBody requestBody(data);
        const auto url = requestBody.getSignInUsernamePasswordEndPoint();
        const auto body = requestBody.getGrantAccessRequestBody();
        this->database.get()->makeSharedReplyHandler(this->database.get()->POST(url,body,"application/json"));
        this->login();
    }
}

void Requests::userSignUp(const QString& email,const QString& password,const QString& telephone)
{
    const auto data = std::make_tuple(email,password,true);
    const RequestBody requestBody(static_cast<SignUpTuple>(data));
    const auto url = requestBody.getSignUpUsernamePasswordEndPoint();
    const auto body = requestBody.getSignUpRequestBody();
    this->database.get()->makeSharedReplyHandler(this->database.get()->POST(url,body,"application/json"));
    this->signUp(telephone);
}

void Requests::universityData()
{
    const RequestBody body(true);
    const auto url = body.getUniversitiesEndPoint();
    this->database.get()->makeSharedReplyHandler(this->database.get()->GET(url));
    this->makeUniversitiesRequest();
}

void Requests::makeUniversitiesRequest()
{
    const auto future = QtFuture::connect(this->database.get()->getReplyHandler(),&DatabaseHandler::Reply::finished).then([this]{
        const auto raw = this->database.get()->getReplyHandler()->readAll();
        Response response(QJsonDocument::fromJson(raw));
        emit Requests::allUniversities(response.getAllUniversities());
    });
}


void Requests::login()
{
    const auto login = QtFuture::connect(this->database.get()->getReplyHandler(),&DatabaseHandler::Reply::readyRead).then([this]{
        const auto document = QJsonDocument::fromJson(this->database.get()->getReplyHandler()->readAll());
        const auto response = document.object();
        if (response.contains("error")){
            emit this->accessDenied();
        }
        else if (response.contains("kind")){
            const auto idToken = response.value("idToken").toString();
            emit this->accessGranted(idToken);
        }
    });
}

void Requests::signUp(const QString& telephone)
{
    const auto signUp = QtFuture::connect(this->database.get()->getReplyHandler(),&DatabaseHandler::Reply::readyRead).then([this]{
        const auto document = QJsonDocument::fromJson(this->database.get()->getReplyHandler()->readAll());
        const auto response = document.object();
        if (response.contains("error")){

        }
        else if (response.contains("kind")){
            const auto idToken = response.value("idToken").toString();
            emit this->signUpSuccessful(idToken);
        }
    });
}

template<class T>
Requests::RequestBody<T>::RequestBody(T requiredData) :
    requiredData(requiredData)
{}

template<class T>
Requests::RequestBody<T>::RequestBody()
{

}

template<class T>
const QJsonDocument Requests::RequestBody<T>::getGrantAccessRequestBody() const
{
    const auto variant = this->getGrantAccessVariant();
    const auto document = QJsonDocument::fromVariant(variant);
    return static_cast<const QJsonDocument>(document);
}

template <class T>
const QJsonDocument Requests::RequestBody<T>::getSignUpRequestBody() const
{
    const auto variant = this->getSignUpVariant();
    const auto document = QJsonDocument::fromVariant(variant);
    return static_cast<const QJsonDocument>(document);
}

template <class T>
const QVariantMap Requests::RequestBody<T>::getSignUpVariant() const
{
    QVariantMap body;
    body["email"] = std::get<SignInSignUp::Email>(this->requiredData);
    body["password"] = std::get<SignInSignUp::Password>(this->requiredData);
    body["returnSecureToken"] = std::get<SignInSignUp::ReturnSecureToken>(this->requiredData);
    return static_cast<const QVariantMap>(body);
}

template<class T>
const QVariantMap Requests::RequestBody<T>::getGrantAccessVariant() const
{
    QVariantMap bodyMap;
    bodyMap["email"] = std::get<SignInSignUp::Email>(this->requiredData);
    bodyMap["password"] = std::get<SignInSignUp::Password>(this->requiredData);
    bodyMap["returnSecureToken"] = std::get<SignInSignUp::ReturnSecureToken>(this->requiredData);
    return static_cast<const QVariantMap>(bodyMap);
}

template<class T>
const QString Requests::RequestBody<T>::getSignInUsernamePasswordEndPoint() const
{
    const auto endPoint = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=";
    return static_cast<const QString>(endPoint + DatabaseHandler::getApiKey());
}

template<class T>
const QString Requests::RequestBody<T>::getSignUpUsernamePasswordEndPoint() const
{
    const auto endPoint = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=";
    return static_cast<const QString>(endPoint + DatabaseHandler::getApiKey());
}

template<class T>
const QString Requests::RequestBody<T>::getUniversitiesEndPoint() const
{
    return this->databaseUrl() + QString("Universities.json");
}

template<class T>
const QString Requests::RequestBody<T>::databaseUrl() const
{
    const auto endPoint = "https://syllabustz-bd7fd-default-rtdb.asia-southeast1.firebasedatabase.app/";
    return static_cast<const QString>(endPoint);
}
