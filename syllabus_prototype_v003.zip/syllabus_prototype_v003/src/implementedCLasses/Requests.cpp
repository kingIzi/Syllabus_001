#include <QDebug>
#include <QJsonObject>
#include "Requests.h"

Requests::Requests(QObject * parent) :
    QObject(parent)
{
    this->database = std::make_shared<DatabaseHandler>();
}

Requests::~Requests()
{
    this->reply->deleteLater();
}

QString Requests::signUpWithEmailAndPasswordEndPoint()
{
    const auto endPoint = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=";
    return (endPoint + this->database.get()->getApiKey());
}

QString Requests::signInWithEmailAndPasswordEndPoint()
{
    const auto endPoint = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=";
    return (endPoint + this->database.get()->getApiKey());
}

QString Requests::getUserDataEndPoint()
{
    const auto endPoint = "https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=";
    return (endPoint + this->database.get()->getApiKey());
}

void Requests::readSignUpResponse()
{
    const auto document = QJsonDocument::fromJson(this->reply->readAll());
    const auto contents = document.object();
    this->readSignUpResponseContent(contents);
}

void Requests::readSignUpResponseContent(const QJsonObject &contents)
{
    if (contents.contains("error")){
        emit this->signUpFailed();
    }
    else if (contents.contains("kind")){
        const auto idToken = contents.value("idToken").toString();
        emit this->registered(idToken);
    }
    else{
        qDebug() << "SOMETHING WENT WRONG";
    }
}

void Requests::readSignInResponseContent(const QJsonObject &contents)
{
    if (contents.contains("error")){
        emit this->accessDenied();
    }
    else if (contents.contains("kind")){
        const auto idToken = contents.value("idToken").toString();
        emit this->accessGranted(idToken);
    }
    else{
        qDebug() << "SOMETHING WENT WRONG";
    }
}

void Requests::readSignInResponse()
{
    const auto rawResponse = this->reply->readAll();
    const auto document = QJsonDocument::fromJson(rawResponse);
    const auto contents = document.object();
    this->readSignInResponseContent(contents);
}

void Requests::makeSignUpWithEmailAndPasswordRequest(const QString &username, const QString &password)
{
    const auto data = static_cast<SignUpTuple>(std::make_tuple(username,password,true));
    PayLoad load(data);
    const auto payLoad = load.getSignUpWithEmailPasswordPayLoad();
    const auto body = load.getDocumentBody(payLoad);
    const auto endPoint = this->signUpWithEmailAndPasswordEndPoint();
    this->reply = this->database.get()->POST(endPoint,body,"application/json");
    QObject::connect(this->reply,&QNetworkReply::readyRead,this,&Requests::readSignUpResponse);
}

void Requests::makeSignInWithEmailAndPasswordRequest(const QString &username, const QString &password)
{
    const auto data = static_cast<SignInTuple>(std::make_tuple(username,password,true));
    PayLoad load(data);
    const auto payLoad = load.getSignInWithEmailPasswordPayLoad();
    const auto body = load.getDocumentBody(payLoad);
    const auto endPoint = this->signInWithEmailAndPasswordEndPoint();
    this->reply = this->database.get()->POST(endPoint,body,"application/json");
    QObject::connect(this->reply,&QNetworkReply::readyRead,this,&Requests::readSignInResponse);
}

void Requests::makeGetUserDataRequest(const QString &idToken)
{

}

template<class T> inline
Requests::PayLoad<T>::PayLoad(T data) :
    data(data)
{}

template<class T> inline
const QVariantMap Requests::PayLoad<T>::getSignUpWithEmailPasswordPayLoad() const
{
    QVariantMap load;
    load["email"] = std::get<SignInSignUp::Username>(this->data);
    load["password"] = std::get<SignInSignUp::Password>(this->data);
    load["returnSecureToken"] = std::get<SignInSignUp::ReturnSecureToken>(this->data);
    return static_cast<const QVariantMap>(load);
}

template<class T> inline
const QVariantMap Requests::PayLoad<T>::getSignInWithEmailPasswordPayLoad() const
{
    QVariantMap load;
    load["email"] = std::get<SignInSignUp::Username>(this->data);
    load["password"] = std::get<SignInSignUp::Password>(this->data);
    load["returnSecureToken"] = std::get<SignInSignUp::ReturnSecureToken>(this->data);
    return static_cast<const QVariantMap>(load);
}

template<class T> inline
const QJsonDocument Requests::PayLoad<T>::getDocumentBody(const QVariantMap& payLoad) const
{
    const auto document = QJsonDocument::fromVariant(payLoad);
    return document;
}


