#include "User.h"
#include <QRegularExpression>

User::User(QObject *parent) : QObject(parent)
{
    this->requests = std::make_shared<Requests>();
    QObject::connect(this->requests.get(),&Requests::accessGranted,this,&User::accessGranted);
    QObject::connect(this->requests.get(),&Requests::accessDenied,this,&User::accessDenied);
    QObject::connect(this->requests.get(), &Requests::registered,this,&User::registered);
}

const Requests *User::getRequests() const
{
    return this->requests.get();
}

void User::accessGranted(QString idToken)
{
    this->userProfile = std::make_unique<UserProfile>(idToken);
    emit this->userSignedIn();
}

void User::accessDenied()
{
    qDebug() << "Access denied";
}

void User::registered(QString idToken)
{
    qDebug() << idToken;
}

void User::grantAccess(const QString &username, const QString &password)
{
    if (username.isEmpty() || password.isEmpty()){
        this->accessDenied();
    }
    else{
        this->requests.get()->makeSignInWithEmailAndPasswordRequest(username,password);
    }
}

void User::signUpUser(const QVariantMap &registerForm)
{
    const auto username = registerForm.value("username").toString();
    const auto password = registerForm.value("password").toString();
    this->requests.get()->makeSignUpWithEmailAndPasswordRequest(username,password);
}

User::UserProfile::UserProfile(const QString &idToken) :
    idToken(idToken.toStdString())
{}

void User::UserProfile::setIdToken(const QString &idToken)
{
    if (idToken.compare(this->idToken.c_str()) != 0){
        this->idToken = idToken.toStdString();
    }
}

const std::string User::UserProfile::getIdToken() const
{
    return this->idToken;
}
