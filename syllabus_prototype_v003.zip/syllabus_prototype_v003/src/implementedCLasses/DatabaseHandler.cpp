#include "DatabaseHandler.h"
#include <QNetworkRequest>


DatabaseHandler::DatabaseHandler(QObject * parent,const QString apiKey) :
    QObject(parent) , apiKey(apiKey)
{
    this->manager = std::make_shared<QNetworkAccessManager>(this);
}

DatabaseHandler::~DatabaseHandler()
{
    this->reply->deleteLater();
}

void DatabaseHandler::setApiKey(const QString &apiKey)
{
    if (this->apiKey != apiKey){
        this->apiKey = apiKey;
    }
}

QString DatabaseHandler::getApiKey()
{
    return this->apiKey;
}

QNetworkReply* DatabaseHandler::GET(const QString &url)
{
    Request request((QUrl(url)));
    this->reply = this->manager.get()->get(request);
    return this->reply;
}

QNetworkReply* DatabaseHandler::POST(const QString &url, const QJsonDocument &document,const char* contentTypeHeader)
{
    Request request((QUrl(url)));
    request.setHeader(Request::ContentTypeHeader,contentTypeHeader);
    return this->manager.get()->post(request,document.toJson());
}

