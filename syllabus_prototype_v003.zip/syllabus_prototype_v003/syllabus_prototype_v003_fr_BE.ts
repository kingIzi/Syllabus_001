<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_BE">
<context>
    <name>ChangePasswordPage</name>
    <message>
        <location filename="forms/qml/pages/ChangePasswordPage.qml" line="21"/>
        <source>Change Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/pages/ChangePasswordPage.qml" line="45"/>
        <source>Passwords must match</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CopyRightLabel</name>
    <message>
        <location filename="forms/qml/components/CopyRightLabel.qml" line="23"/>
        <source>All book publications are school property. Copying and publishing books is prohibited.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditAccountPage</name>
    <message>
        <location filename="forms/qml/pages/EditAccountPage.qml" line="20"/>
        <source>Your details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/pages/EditAccountPage.qml" line="52"/>
        <source>Residential Address</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LoginPage</name>
    <message>
        <location filename="forms/qml/pages/LoginPage.qml" line="53"/>
        <source>MAKOMI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/pages/LoginPage.qml" line="85"/>
        <source>Please, login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/pages/LoginPage.qml" line="91"/>
        <source>Email Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/pages/LoginPage.qml" line="105"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/pages/LoginPage.qml" line="118"/>
        <source>The username or password you entered is incorrect. Please try again...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/pages/LoginPage.qml" line="128"/>
        <source>Forgot your password?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/pages/LoginPage.qml" line="165"/>
        <source>OR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/pages/LoginPage.qml" line="181"/>
        <source>Dont have an account?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/pages/LoginPage.qml" line="186"/>
        <source>Click here</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Navigation</name>
    <message>
        <location filename="forms/qml/Navigation.qml" line="19"/>
        <source>Syllabus</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignUpPage</name>
    <message>
        <location filename="forms/qml/pages/SignUpPage.qml" line="21"/>
        <source>Please Sign Up</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SyllabusDetailsPage</name>
    <message>
        <location filename="forms/qml/pages/SyllabusDetailsPage.qml" line="184"/>
        <source>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc maximus, nulla ut commodo sagittis, sapien dui mattis dui, non pulvinar lorem felis nec erat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc maximus, nulla ut commodo sagittis, sapien dui mattis dui, non pulvinar lorem felis nec erat</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
