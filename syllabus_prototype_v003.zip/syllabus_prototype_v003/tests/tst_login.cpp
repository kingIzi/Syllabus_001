#include <gtest/gtest.h>

#include "User.h"

struct TestSuite : ::testing::Test{
    std::unique_ptr<User> user_ptr = std::make_unique<User>();
    User* user();
};

User* TestSuite::user()
{
    return this->user_ptr.get();
}

//TEST_F(TestSuite,signInEmailAndPassword){
//    const QString username = "scott.izidore@gmail.com";
//    const QString password = "Tengaigetsu@c++174321";
//    this->user()->grantAccess(username,password);
//    EXPECT_TRUE(this->user()->isLoggedIn());
//}

//TEST_F(TestSuite,signInEmailAndPasswordEmpty){
//    const QString username = "";
//    const QString password = "";
//    this->user()->grantAccess(username,password);
//    EXPECT_FALSE(this->user()->isLoggedIn());
//}

//TEST_F(TestSuite,signInEmptyEmailAndPassword){
//    const QString username = "";
//    const QString password = "Tengaigetsu@c++174321";
//    this->user()->grantAccess(username,password);
//    EXPECT_FALSE(this->user()->isLoggedIn());
//}

//TEST_F(TestSuite,signInEmailAndEmptyPassword){
//    const QString username = "scott.izidore@gmail.com";
//    const QString password = "";
//    this->user()->grantAccess(username,password);
//    EXPECT_FALSE(this->user()->isLoggedIn());
//}

//TEST_F(TestSuite,signInEmailAndEmptyPasswordIllFormed){
//    const QString username = "scott.izidore@gmailcom";
//    const QString password = "Tengaigetsu@c++174321";
//    this->user()->grantAccess(username,password);
//    EXPECT_FALSE(this->user()->isLoggedIn());
//}


