#include <QObject>
#include "User.h"
#include "Requests.h"

class AuthTests : public QObject{
    Q_OBJECT
public:
    explicit AuthTests(QObject * parent = nullptr);
    template<class T,class S>
    void connectNetworkReplyReadyRead(T& memory,S slot){

    }
private:
    User user;
};
