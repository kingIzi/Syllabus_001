#include <memory>
#include <QSignalSpy>
#include <QEventLoop>
#include <QTimer>
#include <gtest/gtest.h>

TEST(suitname,testname){
    EXPECT_EQ(1,1);
}


