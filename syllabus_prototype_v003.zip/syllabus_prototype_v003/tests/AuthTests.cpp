#include <QTimer>
#include <QEventLoop>

#include "AuthTests.h"


AuthTests::AuthTests(QObject *parent)
{
    QTimer timer;
    timer.setSingleShot(true);
    QEventLoop loop;
    //connect( sslSocket, &QSslSocket::encrypted, &loop, &QEventLoop::quit );
    //connect( &timer, &QTimer::timeout, &loop, &QEventLoop::quit );
    //timer.start(msTimeout);
    loop.exec();
}
