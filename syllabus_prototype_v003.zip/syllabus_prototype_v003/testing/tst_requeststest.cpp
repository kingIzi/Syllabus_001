#include <memory>
#include <QtTest>
#include <QSignalSpy>
#include <QTimer>
#include <QEventLoop>
#include <QDebug>
#include "Requests.h"

// add necessary includes here

class RequestsTest : public QObject
{
    Q_OBJECT

public:
    RequestsTest();
    ~RequestsTest();
    std::shared_ptr<Requests> requests = std::make_unique<Requests>();
private slots:
    void test_loginUsernamePassword();

};

RequestsTest::RequestsTest()
{

}

RequestsTest::~RequestsTest()
{

}

void RequestsTest::test_loginUsernamePassword()
{

}

QTEST_APPLESS_MAIN(RequestsTest)

#include "tst_requeststest.moc"
