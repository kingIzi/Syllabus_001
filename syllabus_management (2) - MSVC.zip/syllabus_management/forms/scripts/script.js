var sprite;
function createSpriteObjects(filename,parent,properties) {
    sprite = Qt.createComponent(filename);
    sprite = sprite.createObject(parent, properties);
    m_stack.push(sprite)
    if (sprite === null) {
        // Error Handling
        console.log("Error creating object");
    }
}



function getDashBoardGridItemIcons(allIcons){
	const icons = []
	icons.push(allIcons.quiz)
	icons.push(allIcons.assignment)
	icons.push(allIcons.localLibrary)
	icons.push(allIcons.calendarToday)
	icons.push(allIcons.description)
	icons.push(allIcons.dateRange)
	icons.push(allIcons.questionMark)
	icons.push(allIcons.collections)
	icons.push(allIcons.eventBusy)
	icons.push(allIcons.lock)
	icons.push(allIcons.event)
	icons.push(allIcons.logout)
	return icons;
}

function getDashBoardGridItemLabels(){
	const labels = []
	labels.push("Play Quiz")
	labels.push("Assignments")
	labels.push("Library")
	labels.push("Time Table")
	labels.push("Results")
	labels.push("Date Sheet")
	labels.push("Ask a question")
	labels.push("School Gallery")
	labels.push("Leave Application")
	labels.push("Change Password")
    labels.push("Contact us")
	labels.push("Logout")
	return labels
}

function getDashBoardGridListModel(icons,labels){
	if (icons.length !== labels.length) return;
	const model = []
	for (let i = 0; i < labels.length; i++){
		const data = {"icon":icons[i],"label":labels[i]}
		model.push(data)
	}
	return model
}

function gridItemClicked(name,components,stack){
	const labels = getDashBoardGridItemLabels();
	for (let k = 0; k < labels.length; k++){
		if (labels[k] !== name) { continue } 
		stack.push(components[k]);
		break
	}
}

function readingPageIconClicked(text,answer){
	
}
