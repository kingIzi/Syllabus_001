.import QtQuick.Controls.Material 2.15 as Material

function verifyAnswer(answersList,answerCheckBox,modelData){
	// if (modelData === "60 goals"){
	//  	const green = Material.color(Material.Green,Material.Shade800)
	// 	backgroundBorder.border.color = green
	// 	checkIndicator.color = green
	// 	answerCheckBox.contentItem.color = green
	// }
	// else{
	// 	const red = Material.color(Material.Red,Material.Shade800)
	// 	backgroundBorder.border.color = red
	// 	checkIndicator.color = red
	// 	answerCheckBox.contentItem.color = red
	// 	const model = answersList.model
	// 	for (let i = 0; i < model.length; i++){
	// 		if (model[i] !== "60 goals") { continue }
	// 		const green = Material.color(Material.Green,Material.Shade800)
	// 		const item = answersList.itemAtIndex(i)
	// 		item.contentItem.color = green
	// 		item.background.border.color = green
	// 		item.contentItem.color = green
	// 		break
	// 	}
	// }	
	console.log(Material.Material.color)
}