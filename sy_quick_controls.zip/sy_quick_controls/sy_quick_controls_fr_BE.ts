<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_BE">
<context>
    <name>SyCopyRightMsg</name>
    <message>
        <location filename="forms/qml/syComponents/SyCopyRightMsg.qml" line="8"/>
        <source>All book publications are school property. Copying and publishing books is prohibited.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SyHeaderLogo</name>
    <message>
        <location filename="forms/qml/syControls/SyHeaderLogo.qml" line="47"/>
        <source>Tanga</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SyLoginForm</name>
    <message>
        <location filename="forms/qml/syComponents/SyLoginForm.qml" line="16"/>
        <source>Sign in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syComponents/SyLoginForm.qml" line="21"/>
        <source>Email Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syComponents/SyLoginForm.qml" line="35"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syComponents/SyLoginForm.qml" line="48"/>
        <source>Username or password is incorrect. Please try again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syComponents/SyLoginForm.qml" line="57"/>
        <source>Forgot your password?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syComponents/SyLoginForm.qml" line="91"/>
        <source>OR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syComponents/SyLoginForm.qml" line="146"/>
        <source>Dont have an account?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syComponents/SyLoginForm.qml" line="151"/>
        <source>Click here</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SyPoster</name>
    <message>
        <location filename="forms/qml/syControls/SyPoster.qml" line="39"/>
        <source>University of Kinshasa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syControls/SyPoster.qml" line="51"/>
        <source>Civil Engineering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syControls/SyPoster.qml" line="61"/>
        <source>Cours de construction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syControls/SyPoster.qml" line="71"/>
        <source>CE29455</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syControls/SyPoster.qml" line="91"/>
        <source>2eme Grad</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SyPosterDetails</name>
    <message>
        <location filename="forms/qml/syComponents/SyPosterDetails.qml" line="158"/>
        <source>Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syComponents/SyPosterDetails.qml" line="185"/>
        <source>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc maximus, nulla ut commodo sagittis, sapien dui mattis dui, non pulvinar lorem felis nec erat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc maximus, nulla ut commodo sagittis, sapien dui mattis dui, non pulvinar lorem felis nec erat</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SyProfile</name>
    <message>
        <location filename="forms/qml/syComponents/SyProfile.qml" line="104"/>
        <source>Jane Doe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syComponents/SyProfile.qml" line="112"/>
        <source>05 October 1999 | 21 years old</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syComponents/SyProfile.qml" line="135"/>
        <source>Student Details</source>
        <oldsource>Details</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syComponents/SyProfile.qml" line="173"/>
        <source>Parent Contacts</source>
        <oldsource>Contacts</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syComponents/SyProfile.qml" line="339"/>
        <source>Residential address</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SyRegisterPage</name>
    <message>
        <location filename="forms/qml/SyRegisterPage.qml" line="86"/>
        <source>Login now.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SyTopPicks</name>
    <message>
        <location filename="forms/qml/syComponents/SyTopPicks.qml" line="36"/>
        <source>Mathematics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/qml/syComponents/SyTopPicks.qml" line="47"/>
        <source>Your top syllabus picks!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="forms/qml/main.qml" line="22"/>
        <source>Syllabus</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>syComponentsScripts</name>
    <message>
        <location filename="forms/imports/syComponentsScripts.js" line="18"/>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="forms/imports/syComponentsScripts.js" line="18"/>
        <source>Please, register</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
