#pragma once
#include <QDateTime>
#include <QDate>
#include <QList>

class SySchedule : public QObject{
    Q_OBJECT
private:
    Q_PROPERTY(QString startTime READ startTime WRITE setStartTime NOTIFY startTimeChanged)
    Q_PROPERTY(QString endTime READ endTime WRITE setEndTime NOTIFY endTimeChanged)
public:
    explicit SySchedule(QObject * parent = nullptr);
    ~SySchedule();
    QString startTime();
    QString endTime();
signals:
    void startTimeChanged();
    void endTimeChanged();
public slots:
    QVariantList getDaysOfWeek();
    void setStartTime(QString);
    void setEndTime(QString);
private:
    const QList<QString> gregorianDays = {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
    const QList<QString> gregorianMonths = {"January","February","March","April","May","June","July","August","September","October","November","December"};
    QString m_startTime = "09:00 AM";
    QString m_endTime = "10:00 AM";
};
