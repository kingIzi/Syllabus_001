#pragma once

//cpp20 includes
#include <memory>
#include <utility>

//QT Includes
#include <QSyntaxHighlighter>
#include <QQuickTextDocument>
#include <QString>
#include <QObject>
#include <QString>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QUrl>
#include <QJsonDocument>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QFontDatabase>
#include <QQmlContext>
#include <QtQml>
#include <QDebug>
#include <QVariantMap>
#include <QNetworkRequest>
#include <QTextCursor>
#include <QDateTime>
#include <QList>
#include <QDate>



