//js implements interface logic solely
.pragma library
.import "../imports/SyConstantScripts.js" as SyConstants

//signUpWith actions
function signUpWithIconClicked(source,user){
    if (source === signUpWith.google)
        console.log("Google")
    else if (source === signUpWith.facebook)
        console.log("Facebook")
    else
        console.log("Instagram")
}

//toogle between top header text in register.qml
function registerLoginHeaderTextToogle(source){
    const toogle = (!pages.loginForm.localeCompare(source))
    return (toogle) ? qsTr("Welcome") : qsTr("Please, register")
}

//animate username input field on focus changed
function onSyTextFieldFocusChanged(usernameField,usernameInputRect) {
    if (usernameField.focus === true) {
        usernameInputRect.opacity = 1
        usernameInputRect.color = "transparent"
        usernameInputRect.border.width = 1.5
    }
    else if (!(usernameField.text.length > 0)){
        usernameInputRect.opacity = 0.6
        usernameInputRect.color = "#010708"
        usernameInputRect.border.width = 0
    }
}

//open new page.qml item being opened must have a Page as root component
function addStackViewElement(pageName,model,navigationStack){
    var component = Qt.createComponent(pageName);
    var sprite = component.createObject(navigationStack,model);
    navigationStack.push(sprite)
}

//condition to check if textfield left and right icons should display
function displayLeftAndRightTextFieldIcons(m_textField,iconText){
    const condition = (m_textField.text.length === 0) && (iconText);
    return (condition) ? true : false
}

//hide show password logic and cancel text in SyTextField
function toggleSyTextFieldRightIcon(syTextField,fontello){
    if (syTextField.rightIcon === fontello.eye){
        syTextField.echoMode = TextField.Normal
        syTextField.rightIcon = fontello.eyeOff
    }
    else if (syTextField.rightIcon === fontello.eyeOff){
        syTextField.echoMode = TextField.Password
        syTextField.rightIcon = fontello.eye
    }
    else { syTextField.text = "" }
}

//return email address or phone number regex
function getTextFieldRegex(name){
    for (let key in regex){
        if (key !== name) continue
        else return regex[key]
    }
}

//SyTextField is password input when rightIcon is fontello.eye or fontello.eyeOff
function isPasswordSyTextField(rightIcon){
    return ((rightIcon === fontello.eye) || (rightIcon === fontello.eyeOff))
}

//disable syTextField validator for password input
function setSyTextFieldValidator(rightIcon,syTextField){
    if (isPasswordSyTextField(rightIcon))
        syTextField = null
}

//validate register form
function isValidSignUpForm(telephoneInputRect,emailInputRect,createPassword,confirmPassword){
    const phoneAndEmail = isEmptyRegisterForm([telephoneInputRect,emailInputRect,createPassword,confirmPassword])
    const isMatch = ((createPassword.field.text === confirmPassword.field.text))
    if (!isMatch) {
        createPassword.showErrorMessage(errors.passwordMismatch)
        confirmPassword.showErrorMessage(errors.passwordMismatch)
    }
    return (isMatch && phoneAndEmail)
}

//verify that there are no empty values in register form
function isEmptyRegisterForm(syTextFields){
    let empty = false
    for (let i = 0; i < syTextFields.length; i++){
        if (syTextFields[i].field.text.length === 0){
            syTextFields[i].showErrorMessage(errors.emptyField)
            empty = true
        }
        else{
            syTextFields[i].hideErrorMessage()
        }
    }
    return !empty
}

//sign up user
function onRegisterClicked(telephoneInputRect,emailInputRect,createPassword,confirmPassword){
    const isValidForm = isValidSignUpForm(telephoneInputRect,emailInputRect,createPassword,confirmPassword)
    if (isValidForm){

    }
}

//show hide busy indicatoe
function showIsBusy(isBusy,loader,filename) {
    if (isBusy && filename.length !== 0){
        loader.source = ""
        loader.sourceComponent = busy
    }
    else {
        loader.sourceComponent = undefined
        loader.source = filename
    }
}

//toogle grades pick isActive
function selectedGrades(btn,grades){
    for (let i = 0; i < grades.length; i++)
        if (grades[i].isActive === true) grades[i].isActive = false
    btn.isActive = true
}

//toogle syColorPicker checkCircleIcon
function toggleSyColorPickerButtonIcon(grid,btn,titleColor){
    for (let j = 0; j < grid.length; j++){
        const row = grid[j]
        for (let k = 0; k < row.children.length; k++){
            row.children[k].icon.source = ""
        }
    }
    btn.icon.source = getCheckCircleIcon()
    titleColor.color = btn.shadeColor
    titleColor.textColor = "white"
    titleColor.border.width = 0
}

//function to push new page to navigation stack
function stackPushPage(url,pageId,stackId,properties){
    var component = Qt.createComponent(url);
    var sprite = component.createObject(pageId,properties)
    stackId.push(sprite)
}

//change copyright msg horizontal alignment when width higher than 900
function changeCopyrightHorizontalAlignment(width){
    if (width > 900) return Text.AlignHCenter
    else return Text.AlignLeft
}

//return home views options
function getHomeViewOptions(){
    return ["Syllabus","Education","Quotes"]
}

//create qml component filename
function createSpriteObjects(filename,appWindow,properties) {
    const pageComponent = Qt.createComponent(filename);
    if (pageComponent.status === Component.Ready)
        finishCreation(pageComponent,appWindow,properties);
    else
        pageComponent.statusChanged.connect(finishCreation);
    return pageComponent
}

//create qml object and set properties
function finishCreation(pageComponent,appWindow,data) {
    if (pageComponent.status === Component.Ready) {
        const sprite = pageComponent.createObject(appWindow, data);
        if (sprite === null)
            console.log("Error creating object");
        return sprite
    } else if (pageComponent.status === Component.Error) {
        // Error Handling
        console.log("Error loading component:", pageComponent.errorString());
    }
    return null
}

//when SyHeader left icon clicked open settings page or return to previous page
function onHeaderLeftIconClicked(condition,syStackView,profile){
    if (condition){
        profile.open()
    }
    else{
        syStackView.pop()
    }
}

//function to return all icons in navbar
function getSyNavBarModel(){
    return  [SyConstants.images.logo,SyConstants.images.home,SyConstants.images.calendar,SyConstants.images.heart]
}

//function to switch navBar item
function switchSyNavBarItem(index,root){
    switch (index){
    case 0:
        break;
    case 1:
        root.loader.sourceComponent = root.homePage
        break;
    case 2:
        root.loader.sourceComponent = root.calendarPage
        break;
    case 3:
        break;
    default:
        break;
    }
}

function getPlusIconResPath(){
    return SyConstants.images.plus
}

function getFontelloPlus(){
    return SyConstants.fontello.plus
}

function getEventAvailableIcon(){
    return SyConstants.images.eventAvailable
}

function getFontelloClose(){
    return SyConstants.fontello.close
}

function getFontelloLeft(){
    return SyConstants.fontello.left
}

function getCheckCircleIcon(){
    return SyConstants.images.checkCircle
}

function getPredefinedMaterialColors(Material){
    return {
        "red": Material.Red,
        "purple": Material.Purple,
        "blue": Material.Blue,
        "orange": Material.Orange,
        "teal": Material.Teal,
        "cyan": Material.Cyan,
        "brown": Material.Brown,
        "green": Material.Green,
        "bluegrey": Material.BlueGrey
    };
}

function getMaterialColorCodesListModel(Material){
    const predefinedMaterialColors = getPredefinedMaterialColors(Material)
    const colorCodes = []
    for (let key in predefinedMaterialColors){
        const code = predefinedMaterialColors[key]
        colorCodes.push(code)
    }
    return colorCodes;
}

function getMaterialShade(modelData,count,Material){
    switch (count){
    case 1:
        return Material.color(modelData,Material.Shade300)
    case 2:
        return Material.color(modelData,Material.Shade900)
    case 3:
        return Material.color(modelData,Material.Shade500)
    default:
        console.log("Error occored picking color shades...")
        break
    }
}
