#include "include/SySchedule.h"

//initialize class get current date
SySchedule::SySchedule(QObject *parent) : QObject(parent)
{

}

//destructor
SySchedule::~SySchedule()
{

}

//return timetable event start time
QString SySchedule::startTime()
{
    return this->m_startTime;
}

//return timetable event end time
QString SySchedule::endTime()
{
    return this->m_endTime;
}

//return list of working days
QVariantList SySchedule::getDaysOfWeek()
{
    QVariantList daysOfWeek;
    const auto weekDays = 5;
    daysOfWeek.reserve(weekDays);
    for (auto i = 0; i < weekDays; i++){
        daysOfWeek.append(this->gregorianDays[i]);
    }
    return daysOfWeek;
}

//set timetable event start time
void SySchedule::setStartTime(QString start)
{
    if (this->m_startTime != start){
        this->m_startTime = start;
        emit(this->startTimeChanged());
    }
}

//set timetable event end time
void SySchedule::setEndTime(QString end)
{
    if (this->m_endTime != end){
        this->m_endTime = end;
        emit(this->endTimeChanged());
    }
}


