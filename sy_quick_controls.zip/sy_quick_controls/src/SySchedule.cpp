#include "include/SySchedule.h"

//initialize class get current date
SySchedule::SySchedule(QObject *parent) : QObject(parent)
{

}

//destructor
SySchedule::~SySchedule()
{

}

//return timetable event start time
QString SySchedule::startTime()
{
    return this->m_startTime;
}

//return timetable event end time
QString SySchedule::endTime()
{
    return this->m_endTime;
}

//return list of working days
QVariantList SySchedule::getDaysOfWeek()
{
    QVariantList daysOfWeek;
    const auto weekDays = 5;
    daysOfWeek.reserve(weekDays);
    for (auto i = 0; i < weekDays; i++){
        daysOfWeek.append(this->gregorianDays[i]);
    }
    return daysOfWeek;
}

//set timetable event start time
void SySchedule::setStartTime(QString start)
{
    if (this->m_startTime != start){
        this->m_startTime = start;
        emit(this->startTimeChanged());
    }
}

//set timetable event end time
void SySchedule::setEndTime(QString end)
{
    if (this->m_endTime != end){
        this->m_endTime = end;
        emit(this->endTimeChanged());
    }
}

//compare start and end time
bool SySchedule::isValidStartEndTime()
{
    const auto starting = this->getHourAndMinutes(this->m_startTime);
    const auto ending = this->getHourAndMinutes(this->m_endTime);
    const QTime start(starting.first,starting.second);
    const QTime end(ending.first,ending.second);
    return end > start;
}

//get SyTimeTable inputted values
QVariantMap SySchedule::getTimeTableLoad(QObject *parent,const int swipeIndex)
{
    const auto starting = this->getHourAndMinutes(this->m_startTime);
    const auto ending = this->getHourAndMinutes(this->m_endTime);
    const QTime start(starting.first,starting.second);
    const QTime end(ending.first,ending.second);
    const auto position = 3;
    QVariantMap timeTableLoad;
    timeTableLoad["startTime"] = start.toString().right(position);
    timeTableLoad["endTime"] = end.toString().right(position);
    timeTableLoad["course"] = (parent->findChild<QObject*>("course"))->property("text");
    timeTableLoad["professor"] = (parent->findChild<QObject*>("professor"))->property("text");
    timeTableLoad["room"] = (parent->findChild<QObject*>("room"))->property("text");
    timeTableLoad["selectedColor"] = (parent->findChild<QObject*>("selectedColor"))->property("color");
    timeTableLoad["description"] = (parent->findChild<QObject*>("description"))->property("text");
    timeTableLoad["swipeIndex"] = QVariant::fromValue(swipeIndex);
    return timeTableLoad;
}

//return hour and minutes rom start and end time
std::pair<int, int> SySchedule::getHourAndMinutes(QString& time)
{
    const auto position = 2;
    const auto hour = time.left(position).toInt();
    const auto minutes = time.right(position).toInt();
    return std::make_pair(hour,minutes);
}


