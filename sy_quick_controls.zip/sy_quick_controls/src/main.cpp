#include "include/SyApp.h"


int main(int argc, char* argv[])
{
    SyApp app(argc, argv);
    return app.execute();
}
